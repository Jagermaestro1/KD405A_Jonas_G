package KD405A_gabrielsson_j_uppgift4A;

public class Dog {
	
	private String name;
	
	public Dog(String name){
		this.name = name;
	}

	public String getName() {
		return name;
	}
	
}
